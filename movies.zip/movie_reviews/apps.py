from django.apps import AppConfig


class MovieReviewsConfig(AppConfig):
    name = 'movie_reviews'
